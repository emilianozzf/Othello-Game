my_name = 'Emiliano Zhu'
my_birthday = '07/03/1995'
my_hobbies = 'music and sport'
my_favorite_book = '<The Economist>'
my_favorite_movie = '<Inception>'

print ('My name is ' + my_name + '.')
print ('My birthday is ' + my_birthday + '.')
print ('My hobbies are ' + my_hobbies + '.')
print ('My favorite book is ' + my_favorite_book + '.')
print ('My favorite movie is ' + my_favorite_movie + '.')